var searchData=
[
  ['kaddress',['kAddress',['../classONFIAnalyzer.html#afe9716f46e306ad6ebbdaf1bff3414eaad51f1bc68552f8cdd3e02e05dfe408fa',1,'ONFIAnalyzer']]],
  ['kcommand',['kCommand',['../classONFIAnalyzer.html#afe9716f46e306ad6ebbdaf1bff3414eaa56f530b39523db0ebead519b35b4bb20',1,'ONFIAnalyzer']]],
  ['kdata',['kData',['../classONFIAnalyzer.html#afe9716f46e306ad6ebbdaf1bff3414eaa7081fe67d526943278bc5beb3062c941',1,'ONFIAnalyzer']]],
  ['kenvelope',['kEnvelope',['../classONFIAnalyzer.html#afe9716f46e306ad6ebbdaf1bff3414eaa7286287209513ffe9bb7fe00b2ea0af6',1,'ONFIAnalyzer']]],
  ['kinvalid',['kInvalid',['../classONFIAnalyzer.html#afe9716f46e306ad6ebbdaf1bff3414eaaf035142246a642da22b964117b1b681f',1,'ONFIAnalyzer']]]
];
