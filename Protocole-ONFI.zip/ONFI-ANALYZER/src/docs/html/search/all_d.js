var searchData=
[
  ['savesettings',['SaveSettings',['../classONFIAnalyzerSettings.html#abf91f7c8f7b2bf2b720e196a88645b77',1,'ONFIAnalyzerSettings']]],
  ['setsettingsfrominterfaces',['SetSettingsFromInterfaces',['../classONFIAnalyzerSettings.html#a66e5b5d8451d738a3d239e2b66b8a7c9',1,'ONFIAnalyzerSettings']]],
  ['setupresults',['SetupResults',['../classONFIAnalyzer.html#a69ba39c259a7f9bf229cc0f8902816cf',1,'ONFIAnalyzer']]]
];
