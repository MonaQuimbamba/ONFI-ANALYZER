var searchData=
[
  ['hexcharstruct',['HexCharStruct',['../structHexCharStruct.html',1,'']]]
];
