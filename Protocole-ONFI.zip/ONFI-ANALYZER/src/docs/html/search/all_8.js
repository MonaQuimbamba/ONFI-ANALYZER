var searchData=
[
  ['loadsettings',['LoadSettings',['../classONFIAnalyzerSettings.html#a4f052e7c52483e323306de37910f4fcb',1,'ONFIAnalyzerSettings']]]
];
