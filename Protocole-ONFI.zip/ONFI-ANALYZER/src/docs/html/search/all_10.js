var searchData=
[
  ['_7eonfianalyzer',['~ONFIAnalyzer',['../classONFIAnalyzer.html#a7f15e549e9e55f92945a4d4483a885e5',1,'ONFIAnalyzer']]],
  ['_7eonfianalyzerresults',['~ONFIAnalyzerResults',['../classONFIAnalyzerResults.html#a322117ae1eef653abc2d82aef32a49f4',1,'ONFIAnalyzerResults']]],
  ['_7eonfianalyzersettings',['~ONFIAnalyzerSettings',['../classONFIAnalyzerSettings.html#aa9ee3d903afd5f3fb5d0f02e18276121',1,'ONFIAnalyzerSettings']]],
  ['_7eonfisimulationdatagenerator',['~ONFISimulationDataGenerator',['../classONFISimulationDataGenerator.html#a235f43f6304ba5c186fa22930faea75c',1,'ONFISimulationDataGenerator']]]
];
