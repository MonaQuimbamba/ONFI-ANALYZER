var searchData=
[
  ['frametype',['FrameType',['../classONFIAnalyzer.html#afe9716f46e306ad6ebbdaf1bff3414ea',1,'ONFIAnalyzer']]]
];
