var searchData=
[
  ['rbchannel',['rbChannel',['../classONFIAnalyzer.html#ab29886b4f9e2367f904718a652503f52',1,'ONFIAnalyzer']]],
  ['rechannel',['reChannel',['../classONFIAnalyzer.html#a03408066c53d2a03eec89c914b41cfe6',1,'ONFIAnalyzer']]]
];
